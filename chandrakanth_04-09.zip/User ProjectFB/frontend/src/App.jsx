import { BrowserRouter, Routes, Route } from "react-router-dom";

import LoginForm from "./LoginForm";
import RegisterForm from "./RegisterForm";
import UserForm from "./UserForm";
import { Navigate } from "react-router-dom";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LoginForm />} />
        <Route path="/register" element={<RegisterForm />} />
        <Route path="/user" element={<UserForm />} />
        <Route
  path="/user"
  element={
    localStorage.getItem("token") ? <UserForm /> : <Navigate to="/" />
  }
/>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
