import { useState } from "react";
import axios from "axios";
import { useNavigate, Link } from "react-router-dom";
import "./LoginForm.css";
import { GoogleLogin } from "@react-oauth/google";

export default function LoginForm() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:5000/api/auth/login", {
        email,
        password,
      });
      localStorage.setItem("token", res.data.token);
      navigate("/user");
    } catch (err) {
      alert(err.response?.data?.error || "Login failed");
    }
  };

  const handleForgot = async () => {
    if (!email) return alert("Enter email first");
    try {
      await axios.post("http://localhost:5000/api/auth/forgot", { email });
      alert("Reset link sent to your email");
    } catch (err) {
      alert(err.response?.data?.error || "Failed to send reset link");
    }
  };

  return (
    <div className="form-container">
      <h2>Login</h2>

      <GoogleLogin
        onSuccess={async (credentialResponse) => {
          try {
            const res = await axios.post("http://localhost:5000/api/auth/google", {
              token: credentialResponse.credential,
            });
            localStorage.setItem("token", res.data.token);
            navigate("/user");
          } catch (err) {
            console.error("Google login failed", err);
          }
        }}
        onError={() => {
          console.log("Google login failed");
        }}
      />
 <br></br>
      <form onSubmit={handleLogin}>
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <button type="submit">Login</button>
        <button type="button" onClick={handleForgot}>
          Forgot Password
        </button>
      </form>

      <p>
        Don’t have an account? <Link to="/register">Register</Link>
      </p>
    </div>
  );
}
